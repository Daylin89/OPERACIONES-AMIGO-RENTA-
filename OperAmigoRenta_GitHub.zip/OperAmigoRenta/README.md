# Operaciones Amigo Renta — Android v1.0

App Operativa: Customer Service (Work Orders), Fin de Mes (mudanzas, check-out, check-in, limpieza, maletas, maquillaje),
Compras e Inventario y Mantenimiento. Abre la app web del servidor amigorentacliente (/o) con PIN personal por persona.
Se compila con GitHub Actions (.github/workflows/compilar-apk.yml).
